from setuptools import setup

setup(name='dsnd_probability_2020_15',
      version='1.1',
      description='Gaussian and Binomial distributions',     
      packages=[ 'dsnd_probability_2020_15' ],     
      author = 'Ogundeyi Boluwatife',     
     author_email = 'tifeasypeasy@gmail.com',     
    zip_safe=False)
